DIREBAJAAJ LIVE MVP — SELF-CONTAINED FIX

This version does NOT depend on an external JavaScript CDN.
It talks directly to the configured Supabase project using browser fetch(), so UI buttons still work even if a CDN is blocked.

Deploy on Netlify by uploading this ZIP.

Test:
1) Phone A: choose Passenger, fill trip details, Request Bajaj.
2) Phone B: choose Driver, register, turn Online ON.
3) The ride list refreshes automatically every 2.5 seconds.
4) Driver can Accept -> Arrived -> Start -> Complete.
5) Passenger sees status updates automatically.

Before public launch: add driver/admin verification, CAPTCHA/Turnstile, stronger anti-abuse controls, fare rules, safety reporting, and local regulatory checks.
